How to publish this block

1. Upload ctp_places_data_v2_public.js in the repository root
2. Replace map.html with map_intelligent_public_v4.html
3. Replace the city pages with:
   florence.html
   rome.html
   milan.html
   naples.html
   prato.html
   pistoia.html
   bologna.html
   venice.html
4. Save CTP_dataset_v2_public.xlsx on your computer as the current working public dataset

This fixes:
- all current starter records are shown on the map
- public city pages no longer show internal labels
- city pages show richer public-friendly place data
